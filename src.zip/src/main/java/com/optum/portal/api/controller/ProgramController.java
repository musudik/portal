package com.optum.portal.api.controller;

import com.optum.portal.api.model.Program;
import com.optum.portal.api.service.ProgramService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/program")
public class ProgramController {

    @Autowired
    private ProgramService programService;

    @PostMapping("/create")
    public ResponseEntity<Program> create(@RequestBody Program program) {
        try {
            programService.save(program);
            return new ResponseEntity<>(program, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    public ResponseEntity<List<Program>> getPrograms() {
        try {
            List<Program> programs = programService.listPrograms();
            if (programs == null) {
                return new ResponseEntity<>(new ArrayList<>(), HttpStatus.CREATED);
            }
            return new ResponseEntity<>(programs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/program/{name}")
    public ResponseEntity<Program> getProgramByName(@PathVariable("name") String name) {
        try {
            Program program = programService.getProgramByName(name);
            return new ResponseEntity<>(program, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
