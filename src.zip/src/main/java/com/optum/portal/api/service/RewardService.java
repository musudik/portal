package com.optum.portal.api.service;

import com.optum.portal.api.model.Reward;
import com.optum.portal.api.repository.IRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RewardService {

    @Autowired
    private IRewardRepository rewardRepository;

    public Reward save(Reward reward) {
        return rewardRepository.save(reward);
    }

    public List<Reward> listRewards() { return rewardRepository.findAll(); }
}
