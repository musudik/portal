package com.optum.portal.api.service;

import com.optum.portal.api.model.User;
import com.optum.portal.api.repository.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    @Autowired
    private IUserRepository userRepository;

    public User save(User user) {
        return userRepository.save(user);
    }

    public User login(User user) throws UsernameNotFoundException {
        final User loggedUser = userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
        if(loggedUser == null) {
            throw new UsernameNotFoundException(user.getUsername());
        }
        return loggedUser;
    }
}
