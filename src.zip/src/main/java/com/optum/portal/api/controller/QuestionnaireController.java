package com.optum.portal.api.controller;

import com.optum.portal.api.model.Questionnaire;
import com.optum.portal.api.service.QuestionnaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/questionnaire")
public class QuestionnaireController {

    @Autowired
    private QuestionnaireService questionnaireService;

    @PostMapping("/create")
    public ResponseEntity<Questionnaire> create(@RequestBody Questionnaire questionnaire) {
        try {
            questionnaireService.save(questionnaire);
            return new ResponseEntity<>(questionnaire, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    public ResponseEntity<List<Questionnaire>> getPrograms() {
        try {
            List<Questionnaire> questionnaires = questionnaireService.listQuestionnaires();
            if (questionnaires == null) {
                return new ResponseEntity<>(new ArrayList<>(), HttpStatus.CREATED);
            }
            return new ResponseEntity<>(questionnaires, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
