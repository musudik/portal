package com.optum.portal.api.service;

import com.optum.portal.api.model.Questionnaire;
import com.optum.portal.api.repository.IQuestionnaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionnaireService {

    @Autowired
    private IQuestionnaireRepository questionnaireRepository;

    public Questionnaire save(Questionnaire Questionnaire) {
        return questionnaireRepository.save(Questionnaire);
    }

    public List<Questionnaire> listQuestionnaires() { return questionnaireRepository.findAll(); }

}
