package com.optum.portal.api.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

@Entity
@Table(name = "questionnaire", uniqueConstraints={@UniqueConstraint(columnNames = {"question"})})
@SequenceGenerator(name="seq_questionnaire", initialValue=1000, allocationSize=1)
public class Questionnaire extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	protected Questionnaire() {
	}
	public Questionnaire(String question, String description) {
		super();
		this.question = question;
		this.description = description;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator="seq_Questionnaire")
	@Column(name = "questionnaire_id", nullable = false, insertable = false, updatable = false)
	Long questionnaireId;
	
	@NotEmpty(message = "question can't be empty")
	@Column(name = "question", nullable = false)
    private String question;

	@NotEmpty(message = "questionnaire description can't be empty")
	@Column(name = "description", nullable = false)
	private String description;
}
