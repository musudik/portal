package com.optum.portal.api.service;

import com.optum.portal.api.model.Program;
import com.optum.portal.api.repository.IProgramRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProgramService {

    @Autowired
    private IProgramRepository programRepository;

    public Program save(Program program) {
        return programRepository.save(program);
    }

    public List<Program> listPrograms() { return programRepository.findAll(); }

    public Program getProgramByName(String name) { return programRepository.findByName(name); }
}
